# Template Beamer SENAI - Governança de TI (Overleaf)

Este repositório contém o **Template LaTeX / Beamer** limpo de conteúdo, projetado para a criação modular de slides da disciplina de **Governança de TI**, pronto para importação direta no **Overleaf**.

---

## 📁 Estrutura de Arquivos

```text
latex_template/
├── main.tex              # Arquivo principal de compilação
├── senai_theme.sty       # Pacote de estilo, cores oficiais e componentes visuais
├── slides/
│   ├── semana_01.tex     # Template limpo com a estrutura dos slides da Semana 1
│   └── semana_02.tex     # (Adicione novos arquivos semanais aqui)
└── README_OVERLEAF.md    # Instruções de uso no Overleaf
```

---

## 🚀 Como Importar no Overleaf

1. Faça o download da pasta `latex_template` em formato `.zip`.
2. No **Overleaf**, clique em **New Project** > **Upload Project**.
3. Selecione o arquivo `.zip` para carregar todos os arquivos mantendo a estrutura de pastas.
4. Certifique-se de que o arquivo principal de compilação esteja configurado como `main.tex`.
5. Clique em **Recompile** para gerar o PDF da apresentação.

---

## 🔄 Como Organizar as Aulas Semanais

No arquivo `main.tex`, utilize a diretiva `\input{...}` para importar os slides de cada semana:

```latex
\begin{document}

% Semana 01
\input{slides/semana_01.tex}

% Semana 02
% \input{slides/semana_02.tex}

\end{document}
```

Para criar uma nova aula (ex: **Semana 02**):
1. Crie o arquivo `slides/semana_02.tex`.
2. Copie a estrutura de exemplo de `slides/semana_01.tex`.
3. No `main.tex`, descomente ou adicione `\input{slides/semana_02.tex}`.

---

## 🎨 Componentes & Cards Disponíveis

O arquivo `senai_theme.sty` disponibiliza ambientes e blocos estilizados com a identidade visual do SENAI:

### 1. Slide de Capa
```latex
\senaicover
  {Título da Aula}
  {Subtítulo / Módulo}
  {Unidade Curricular: Governança de TI}
  {Prof. André Souza}
```

### 2. Cabeçalho Estruturado (Tag + Título)
```latex
\begin{senaiframe}{TAG SUPERIOR}{Título do Slide}
  % Conteúdo do slide
\end{senaiframe}
```

### 3. Cards Estilizados (`tcolorbox`)
- `senaicard`: Card padrão com fundo neutro e borda slate.
- `senaibluecard`: Card azul (conceitos, definições, governança).
- `senairedcard`: Card vermelho (riscos, SOX, exigências críticas).
- `senaiambercard`: Card âmbar (alertas, ética, atenção).
- `senaigreencard`: Card verde (prática, aplicação no PDGTI, resultados).

Exemplo de uso:
```latex
\begin{tcolorbox}[senaibluecard, title={Título do Card}]
  \begin{itemize}
    \item \textbf{Item:} Descrição do item.
  \end{itemize}
\end{tcolorbox}
```
